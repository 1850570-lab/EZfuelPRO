// EZ FUEL — savings calculator
// Math: monthlySavings = gallons * discountCents / 100

(function () {
  // Discount tiers by monthly gallon volume (cents per gallon)
  // Easy to customize — edit these values to change public savings figures.
  const TIERS = [
    { min: 0,      max: 4999,   cpg: 30, label: "Starter" },
    { min: 5000,   max: 19999,  cpg: 45, label: "Growth" },
    { min: 20000,  max: 49999,  cpg: 60, label: "Pro" },
    { min: 50000,  max: Infinity, cpg: 80, label: "Enterprise" },
  ];

  function tierFor(gallons) {
    return TIERS.find(t => gallons >= t.min && gallons <= t.max) || TIERS[0];
  }

  function fmtUSD(n) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency', currency: 'USD', maximumFractionDigits: 0
    }).format(Math.round(n));
  }

  function bind(root) {
    const input = root.querySelector('[data-calc-input]');
    const outMonthly = root.querySelector('[data-calc-monthly]');
    const outAnnual = root.querySelector('[data-calc-annual]');
    const outTier = root.querySelector('[data-calc-tier]');
    const outCpg = root.querySelector('[data-calc-cpg]');
    const slider = root.querySelector('[data-calc-slider]');

    function update() {
      const gallons = Math.max(0, parseFloat(input.value) || 0);
      const t = tierFor(gallons);
      const monthly = gallons * t.cpg / 100;
      const annual = monthly * 12;
      outMonthly.textContent = fmtUSD(monthly);
      outAnnual.textContent = fmtUSD(annual);
      outTier.textContent = t.label;
      outCpg.textContent = `${t.cpg}¢/gal`;
    }

    input.addEventListener('input', () => {
      if (slider) slider.value = Math.min(Math.max(parseFloat(input.value) || 0, 0), slider.max);
      update();
    });
    if (slider) {
      slider.addEventListener('input', () => {
        input.value = slider.value;
        update();
      });
    }
    update();
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-savings-calculator]').forEach(bind);
  });
})();
